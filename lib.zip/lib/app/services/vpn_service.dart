// 📁 vpn_service.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:installed_apps/installed_apps.dart';

class AppInfo {
  final String name;
  final String packageName;
  final Uint8List icon;
  final RxBool isBlocked;

  AppInfo({
    required this.name,
    required this.packageName,
    required this.icon,
    bool isBlocked = false,
  }) : isBlocked = RxBool(isBlocked);
}

class NativeVPN {
  static const _channel = MethodChannel('blocker.blocker/vpn');

  static Future<void> startVPN(List<String> blockedApps) async {
    try {
      await _channel.invokeMethod('startVPN', {'blockedApps': blockedApps});
    } catch (e) {
      debugPrint('Failed to start VPN: $e');
    }
  }

  static Future<void> stopVPN() async {
    try {
      await _channel.invokeMethod('stopVPN');
    } catch (e) {
      debugPrint('Failed to stop VPN: $e');
    }
  }

  static Future<bool> isVPNRunning() async {
    try {
      final result = await _channel.invokeMethod<bool>('checkVPN');
      return result ?? false;
    } catch (e) {
      debugPrint('Error checking VPN status: $e');
      return false;
    }
  }
}

class VPNService extends GetxService {
  Future<List<AppInfo>> getInstalledApps() async {
    try {
      final apps = await InstalledApps.getInstalledApps(true, true);
      return await Future.wait(apps.map((app) async {
        return AppInfo(
          name: app.name,
          packageName: app.packageName,
          icon: app.icon ?? Uint8List(0),
        );
      }));
    } catch (e) {
      Get.snackbar('Error', 'Failed to get installed apps: $e');
      return [];
    }
  }

  Future<bool> isVPNEnabled() async {
    return await NativeVPN.isVPNRunning();
  }

  Future<void> blockApp(AppInfo app, List<String> currentBlockedPackages) async {
    currentBlockedPackages.add(app.packageName);

    await NativeVPN.startVPN(currentBlockedPackages);
  }

  Future<void> unblockApp(AppInfo app, List<String> currentBlockedPackages) async {
    currentBlockedPackages.remove(app.packageName);
    await NativeVPN.startVPN(currentBlockedPackages);
  }
}
