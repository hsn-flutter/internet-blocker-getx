import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../controllers/home_controller.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('VPN Blocker'),
        centerTitle: true,
        actions: [
          Obx(() => Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Switch(
                  value: controller.isVPNEnabled.value,
                  onChanged: controller.toggleVPN,
                ),
          )),
        ],
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }

        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: controller.searchController,
                decoration: const InputDecoration(
                  hintText: 'Search apps...',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) => controller.searchQuery.value = value,
              ),
            ),
            Expanded(
              child: Obx(() => ListView.builder(
                    itemCount: controller.filteredApps.length,
                    itemBuilder: (context, index) {
                      final app = controller.filteredApps[index];
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundImage: MemoryImage(app.icon),
                        ),
                        title: Text(app.name),
                        subtitle: Text(app.packageName),
                        trailing: Obx(() => Switch(
                              value: app.isBlocked.value,
                              onChanged: (value) => controller.toggleAppBlocking(app, value),
                            )),
                      );
                    },
                  )),
            ),
          ],
        );
      }),
    );
  }
}
